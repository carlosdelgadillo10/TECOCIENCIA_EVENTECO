#Codigo CLiente
from flask import Flask, render_template, request
import socket
import json

app = Flask(__name__)
app.static_folder='static'

# Configuración del servidor al que se conectará el cliente
host = '127.0.0.1'  # Dirección IP del servidor
port = 12345

def enviar_solicitud_al_servidor(accion, data=None):
    try:
        # Crear un socket del cliente y conectar al servidor
        client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        client_socket.connect((host, port))
        # Crear un diccionario JSON para la solicitud
        solicitud = {"accion": accion}
        if data:
            solicitud.update(data)
        # Enviar la solicitud al servidor
        message = json.dumps(solicitud)
        print(f"Enviando solicitud al servidor: {message}")
        client_socket.send(message.encode('utf-8'))
        # Recibir la respuesta del servidor
        response = client_socket.recv(1024).decode('utf-8')
        # Cerrar el socket del cliente
        client_socket.close()

        return response

    except Exception as e:
        return str(e)

@app.route("/")
def index():
    return render_template("login.html")

@app.route("/iniciar_sesion", methods=["POST"])
def iniciar_sesion():
    usuario = request.form["usuario"]
    password = request.form["password"]
    permiso=request.form["permiso"]

    # Enviar solicitud al servidor para iniciar sesión
    response = enviar_solicitud_al_servidor("iniciar_sesion", {"usuario": usuario, "password": password,"permiso": permiso})

    if response == "Sesion iniciada con exito":
        return render_template("menuusuario.html", mensaje="Sesión iniciada con éxito")
    elif response == "Sesion admin iniciada con exito":
        return render_template("menuadmin.html", mensaje="Sesión iniciada con éxito")
    else:
        return render_template("login.html", mensaje="Usuario, contraseña o permiso incorrectos" )


@app.route("/consultar_eventos", methods=["GET"])
def consultar_eventos():
    # Enviar solicitud al servidor para consultar eventos
    response = enviar_solicitud_al_servidor("consultar_eventos")

    try:
        # Intentar decodificar la respuesta JSON
        eventos = json.loads(response)
        return render_template("consultar.html", eventos=eventos)
    except json.JSONDecodeError as e:
        return f"Error al decodificar JSON en la respuesta: {str(e)}"

@app.route("/consultar_eventos_user", methods=["GET"])
def consultar_event():
    # Enviar solicitud al servidor para consultar eventos
    response = enviar_solicitud_al_servidor("consultar_eventos")

    try:
        # Intentar decodificar la respuesta JSON
        eventos = json.loads(response)
        return render_template("consultar_user.html", eventos=eventos)
    except json.JSONDecodeError as e:
        return f"Error al decodificar JSON en la respuesta: {str(e)}"

@app.route("/obtener_nombre_eventos", methods=["GET"])
def obtener_nombre_eventos():
    # Enviar solicitud al servidor para consultar eventos
    print("hola")
    response = enviar_solicitud_al_servidor("obtener_nombre_eventos")
    print(response)
    try:

        eventos = json.loads(response)

        return render_template("modificar_evento.html", eventos=eventos)
    except json.JSONDecodeError as e:
        return f"Error al decodificar JSON en la respuesta: {str(e)}"
    
@app.route("/obtener_a_eliminar", methods=["GET"])
def obtener_a_eliminar():
    # Enviar solicitud al servidor para consultar eventos
    response = enviar_solicitud_al_servidor("obtener_a_eliminar")
    print(response)
    try:
        eventos = json.loads(response)
        return render_template("eliminar_evento.html", eventos=eventos)
    except json.JSONDecodeError as e:
        return f"Error al decodificar JSON en la respuesta: {str(e)}"


@app.route("/eliminar_evento", methods=["POST"])
def eliminar_evento():
    nombre_eliminar = request.form["nombre_eliminar"]
    # Enviar solicitud al servidor para iniciar sesión
    response = enviar_solicitud_al_servidor("eliminar_evento", {"nombre_eliminar": nombre_eliminar})

    if response == "Evento eliminado con éxito":
        return render_template("menuadmin.html", mensaje="Evento eliminado con éxito")
    else:
        return render_template("soca.html")

@app.route("/backmenu_admin", methods=["GET"])
def mostrar_anterior_admin():
    return render_template("menuadmin.html")

@app.route("/backmenu_user", methods=["GET"])
def mostrar_anterior_user():
    return render_template("menuusuario.html")

@app.route("/mostrar_insertar_usuario", methods=["GET"])
def mostrar_registrar_usuario():
    return render_template("insertar_usuario.html")

@app.route("/backmenu_login", methods=["GET"])
def mostrar_anterior_login():
    return render_template("login.html")

@app.route("/mostrar_insertar_evento", methods=["GET"])
def mostrar_insertar_evento():
    return render_template("insertar_evento.html")

@app.route("/mostrar_modificar_evento", methods=["GET"])
def mostrar_modificar_evento():
    return render_template("modificar_evento.html")

@app.route("/mostrar_eliminar_evento", methods=["GET"])
def mostrar_eliminar_evento():
    return render_template("eliminar_evento.html")

@app.route("/insertar_evento", methods=["POST"])
def procesar_formulario_insertar_evento():
    nombre = request.form["nombre"]
    descripcion = request.form["descripcion"]
    lugar = request.form["lugar"]
    fecha = request.form["fecha"]
    tipo = request.form["tipo"]
    relacion_id_decanato = request.form["relacion_id_decanato"]

    # Llamar a la función de inserción de eventos y obtener la respuesta
    response = enviar_solicitud_al_servidor("insertar_evento",{"nombre": nombre, "descripcion":descripcion,"lugar": lugar,"fecha": fecha, "tipo": tipo, "relacion_id_decanato":relacion_id_decanato})
    if response == "Evento insertado con éxito":
        return render_template("menuadmin.html", mensaje="Evento insertado con éxito")
    else:
        return render_template("error.html", mensaje="Error al insertar el evento")
    
@app.route("/insertar_usuario", methods=["POST"])
def procesar_formulario_insertar_usuario():
    usuario = request.form["usuario"]
    password = request.form["password"]

    # Llamar a la función de inserción de eventos y obtener la respuesta
    response = enviar_solicitud_al_servidor("insertar_usuario",{"usuario": usuario, "password":password})
    if response == "Usuario insertado con éxito":
        return render_template("login.html", mensaje="Usuario insertado con éxito")
    else:
        return render_template("error.html", mensaje="Error al insertar el usuario")

@app.route("/modificar_evento", methods=["POST"])
def procesar_formulario_modificar_evento():
    nombre_modificar=request.form["nombre_modificar"]
    nombre = request.form["nombre"]
    descripcion = request.form["descripcion"]
    lugar = request.form["lugar"]
    fecha = request.form["fecha"]
    tipo = request.form["tipo"]
    relacion_id_decanato = request.form["relacion_id_decanato"]
    response = enviar_solicitud_al_servidor("modificar_evento",{"nombre": nombre, "descripcion":descripcion,"lugar": lugar,"fecha": fecha, "tipo": tipo, "relacion_id_decanato":relacion_id_decanato,"nombre_modificar":nombre_modificar})
    if response == "Evento modificado con éxito":
        return render_template("menuadmin.html", mensaje="Evento modificado con éxito")
    else:
        return render_template("modificar_evento.html", mensaje="Error al modificar el evento")
    
@app.route("/eliminar_evento", methods=["POST"])
def procesar_formulario_eliminar_evento():
    nombre_eliminar=request.form["nombre_eliminar"]
    response = enviar_solicitud_al_servidor("eliminar_evento",{"nombre_eliminar":nombre_eliminar})
    if response == "Evento eliminado con éxito":
        return render_template("menuadmin.html", mensaje="Evento eliminado con éxito")
    else:
        return render_template("eliminar_evento.html", mensaje="Error al eliminar el evento")

if __name__ == '__main__':
    app.run(debug=True)




