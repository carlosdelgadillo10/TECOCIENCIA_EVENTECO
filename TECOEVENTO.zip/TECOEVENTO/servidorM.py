#Codigo Servidor 
import socket
import threading
import sqlite3 as sq
import json
import datetime
class EventecoApp:
    def __init__(self):
        # Crear una conexión a la base de datos en el constructor si es necesario.
        self.laConexion= None
        self.miCursor = None
    def obten_conexion_cursor(self):
        self.laConexion = sq.connect("EVENTECO.db") # Utiliza un archivo de base de datos
        self.miCursor = self.laConexion.cursor()

    def init_database(self):
        try:
            self.obten_conexion_cursor()
            # Solo crea la tabla una vez, esto se hace para que no marque error
            self.miCursor.execute('''CREATE TABLE IF NOT EXISTS decanatos (
                id_decanato INTEGER PRIMARY KEY,
                nombre TEXT NOT NULL)''')

            self.miCursor.execute('''CREATE TABLE IF NOT EXISTS eventos (
                id_evento INTEGER PRIMARY KEY,
                nombre TEXT NOT NULL,
                descripcion TEXT NOT NULL,
                lugar TEXT NOT NULL,
                fecha DATE NOT NULL,
                tipo TEXT NOT NULL,
                relacion_id_decanato INT,
                FOREIGN KEY (relacion_id_decanato) REFERENCES decanatos(id_decanato))''')

            self.miCursor.execute('''CREATE TABLE IF NOT EXISTS usuarios ( 
                usuario INTEGER Not Null,
                password VARCHAR(50) Not Null,
                permisos int,
                relacion_id_decanatou INT,
                FOREIGN KEY (relacion_id_decanatou) REFERENCES decanatos(id_decanato))''')

            # Verifica si ya hay un usuario en la tabla de usuarios
            self.miCursor.execute("SELECT usuario FROM usuarios LIMIT 1")
            primer_usuario = self.miCursor.fetchone()
            if not primer_usuario:
                # Si no hay usuarios, inserta uno de ejemplo
                self.miCursor.execute("INSERT INTO usuarios (usuario, password) VALUES (1, 'a1234')")
            """self.miCursor.execute("INSERT INTO usuarios (usuario, contraseña) VALUES (1, 'a1234')")
            self.miCursor.execute("INSERT INTO decanatos (nombre) VALUES ('default')")
            self.miCursor.execute("INSERT INTO eventos (nombre, descripcion, lugar, fecha, tipo, relacion_id_decanato) VALUES ('evento prueba', 'prueba', 'prueba', 'uag', 'prueba', 0)")
            # Importante: confirmar los cambios"""
            self.laConexion.commit()
            # Mensaje de éxito
            print("Base de datos", "Base de datos creada con éxito")
        except sq.Error as e:
            print("Bienvenido a Eventeco", "La mejor plataforma")

    def iniciar_sesion(self, usuario, password,permiso):
        try:
            # Consultar la base de datos para verificar las credenciales
            self.miCursor.execute("SELECT * FROM usuarios WHERE usuario = ? AND password = ?", (usuario, password))
            resultado = self.miCursor.fetchone()
            if resultado:
                # Verificar el permiso si se ha ingresado
                if not permiso:
                    print("entre a la funcion")
                    return "Sesion iniciada con exito"
                elif permiso == "152003":
                    return"Sesion admin iniciada con exito"
                else:
                    print("Error al iniciar sesión:", str(e))
                    return "Error al iniciar sesión"
            else:
                return "Usuario o contraseña incorrectos"
        except sq.Error as e:
            print("Error al iniciar sesión:", str(e))
            return "Error al iniciar sesión"

    def obtener_nombre_eventos(self):
            try:
                self.miCursor.execute("SELECT nombre FROM eventos")
                nombre_eventos=self.miCursor.fetchall()
                nombre_eventos=[nombre[0] for nombre in nombre_eventos]
                return json.dumps({"nombre_eventos":nombre_eventos})
            except sq.Error as e:
                return json.dumps({"nombre_eventos":[]})
    def obtener_a_eliminar(self):
        try:
            self.miCursor.execute("SELECT nombre FROM eventos")
            nombre_eventos=self.miCursor.fetchall()
            nombre_eventos=[nombre[0] for nombre in nombre_eventos]
            return json.dumps({"nombre_eventos":nombre_eventos})
        except sq.Error as e:
            return json.dumps({"nombre_eventos":[]})
            
    def insertar_evento(self, nombre, descripcion, lugar, fecha, tipo, relacion_id_decanato): 
        try:
            # Obtener la fecha y hora actual en formato de cadena
            fecha_actual = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

            # Insertar un nuevo evento en la base de datos
            self.miCursor.execute("INSERT INTO eventos (nombre, descripcion, lugar, fecha, tipo , relacion_id_decanato) VALUES (?, ?, ?, ?, ?, ?)", 
                (nombre, descripcion, lugar, fecha,tipo, relacion_id_decanato)) 

            # Importante: confirmar los cambios
            self.laConexion.commit()
            return "Evento insertado con éxito"
        except sq.Error as e:
            print("Error al insertar evento:", str(e))
            return "Error al insertar evento"
    
    def insertar_usuario(self, usuario, password): 
        try:
            # Obtener la fecha y hora actual en formato de cadena
            fecha_actual = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

            # Insertar un nuevo evento en la base de datos
            self.miCursor.execute("INSERT INTO usuarios (usuario,password) VALUES (?, ?)", 
                (usuario,password)) 

            # Importante: confirmar los cambios
            self.laConexion.commit()
            return "Usuario insertado con éxito"
        except sq.Error as e:
            print("Error al insertar usuario:", str(e))
            return "Error al insertar usuario"

    def modificar_evento(self, nombre, descripcion, lugar, fecha, tipo, relacion_id_decanato, nombre_modificar):
        try:
            # Modificar un evento en la base de datos por su ID
            self.miCursor.execute("UPDATE eventos SET nombre=?, descripcion=?, lugar=?, fecha=?, tipo=?, relacion_id_decanato=? WHERE nombre=?",
                (nombre, descripcion, lugar, fecha, tipo, relacion_id_decanato, nombre_modificar))
            self.laConexion.commit()
            return "Evento modificado con éxito"
        except sq.Error as e:
            print("Error al modificar evento:", str(e))
            return "Error al modificar evento"

    def eliminar_evento(self, nombre_eliminar):
        try:
            self.miCursor.execute("DELETE FROM eventos WHERE nombre=?", (nombre_eliminar,))
            self.laConexion.commit()
            print("sigo en la funcion")
            return "Evento eliminado con éxito"
        except sq.Error as e:
            print("Error al eliminar evento:", str(e))
            return "Error al eliminar evento"
            
# Crear una instancia de la aplicación
app = EventecoApp()

app.init_database()
# Configuración del servidor
host = '0.0.0.0'  # Escucha en todas las interfaces de red
port = 12345

# Crear un socket del servidor
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Vincular el servidor a la dirección y el puerto
server_socket.bind((host, port))

# Escuchar conexiones entrantes (máximo 5 clientes en espera)
server_socket.listen(5)
print(f"Servidor escuchando en {host}:{port}")

# Lista para almacenar las conexiones de los clientes
client_connections = [] 

def handle_client(client_socket):
    # Crear una nueva conexión y cursor para este hilo
    app.obten_conexion_cursor()

    while True:
        data = client_socket.recv(1024).decode('utf-8')
        if not data:
            break
        print(f"Recibido: {data}")

        json_data = json.loads(data)  # Decodificar la variable data como JSON

        if "accion" in json_data:
            if json_data["accion"] == "iniciar_sesion":
                if "usuario" in json_data and "password" in json_data:
                    usuario = json_data["usuario"]
                    password = json_data["password"]
                    permiso = json_data["permiso"]
                    # Llamar a la función de inicio de sesión y obtener la respuesta
                    respuesta = app.iniciar_sesion(usuario, password,permiso)
                    client_socket.send(respuesta.encode('utf-8'))
                else:
                    respuesta = "Faltan campos en la solicitud de inicio de sesión"
                    client_socket.send(respuesta.encode('utf-8'))
            elif json_data["accion"] == "consultar_eventos":
                # Utilizar el cursor de este hilo para consultar eventos
                app.obten_conexion_cursor()  # Asegurarse de tener la conexión actualizada
                app.miCursor.execute("SELECT * FROM eventos")
                eventos = app.miCursor.fetchall()
                app.laConexion.commit()
                eventos_json = json.dumps(eventos)
                client_socket.send(eventos_json.encode('utf-8'))
            
            elif json_data["accion"] == "consultar_eventos_user":
                # Utilizar el cursor de este hilo para consultar eventos
                app.obten_conexion_cursor()  # Asegurarse de tener la conexión actualizada
                app.miCursor.execute("SELECT * FROM eventos")
                eventos = app.miCursor.fetchall()
                app.laConexion.commit()
                eventos_json = json.dumps(eventos)
                client_socket.send(eventos_json.encode('utf-8'))
            
            elif json_data["accion"] == "obtener_nombre_eventos": 
                print("entre a la funcion")
                # Utilizar el cursor de este hilo para consultar eventos
                app.obten_conexion_cursor()  # Asegurarse de tener la conexión actualizada
                app.miCursor.execute("SELECT nombre FROM eventos")
                nombre_eventos = app.miCursor.fetchall()
                app.laConexion.commit()
                nombre_eventos_json=json.dumps(nombre_eventos)
                print(nombre_eventos_json) 
                client_socket.send(nombre_eventos_json.encode('utf-8'))
            
            elif json_data["accion"] == "obtener_a_eliminar": 
                app.obten_conexion_cursor()  # Asegurarse de tener la conexión actualizada
                app.miCursor.execute("SELECT nombre FROM eventos")
                nombre_eventos = app.miCursor.fetchall()
                app.laConexion.commit()
                nombre_eventos_json=json.dumps(nombre_eventos)
                print(nombre_eventos_json) 
                client_socket.send(nombre_eventos_json.encode('utf-8'))

            elif json_data["accion"] == "insertar_evento":
                print("Entre a la funcion insertar")
                if "nombre" in json_data and "descripcion" and "lugar" and "fecha" and "tipo" and "relacion_id_decanato" in json_data:
                    nombre = json_data["nombre"]
                    descripcion = json_data["descripcion"]
                    lugar = json_data["lugar"]
                    fecha = json_data["fecha"]
                    tipo = json_data["tipo"]
                    relacion_id_decanato = json_data["relacion_id_decanato"]
                    respuesta = app.insertar_evento(nombre, descripcion,lugar,fecha,tipo,relacion_id_decanato)
                    client_socket.send(respuesta.encode('utf-8'))
                else:
                    respuesta = "Formato incorrecto. Debe ser 'insertar_evento,nombre,descripcion,lugar,fecha,tipo,relacion_id_decanato'"
                    client_socket.send(respuesta.encode('utf-8'))
            
            elif json_data["accion"] == "insertar_usuario":
                print("Entre a la funcion insertar")
                if "usuario" in json_data and "password" in json_data:
                    usuario = json_data["usuario"]
                    password = json_data["password"]
                    respuesta = app.insertar_usuario(usuario,password)
                    client_socket.send(respuesta.encode('utf-8'))
                else:
                    respuesta = "Formato incorrecto. Debe ser 'usuario,password'"
                    client_socket.send(respuesta.encode('utf-8'))

            elif json_data["accion"]== "modificar_evento":
                print("Entre a la funcion modificar")
                if "nombre" in json_data and "descripcion" and "lugar" and "fecha" and "tipo" and "relacion_id_decanato" in json_data:
                    nombre = json_data["nombre"]
                    descripcion = json_data["descripcion"]
                    lugar = json_data["lugar"]
                    fecha = json_data["fecha"]
                    tipo = json_data["tipo"]
                    relacion_id_decanato = json_data["relacion_id_decanato"]
                    nombre_modificar=json_data["nombre_modificar"]
                    respuesta = app.modificar_evento(nombre, descripcion,lugar,fecha,tipo,relacion_id_decanato,nombre_modificar)
                    client_socket.send(respuesta.encode('utf-8'))
                else:
                    mensaje = "Formato incorrecto. Debe ser 'modificar_evento,id_evento,nombre,descripcion,lugar,fecha,tipo,relacion_id_decanato'"
                    client_socket.send(mensaje.encode('utf-8'))

            elif json_data["accion"] == "eliminar_evento":
                if "nombre_eliminar" in json_data:
                    print("entre a la funcion")
                    nombre_eliminar = json_data["nombre_eliminar"]
                    respuesta = app.eliminar_evento(nombre_eliminar)
                    client_socket.send(respuesta.encode('utf-8'))
                else:
                    respuesta = "Faltan campos en la solicitud de eliminar evento"
                    client_socket.send(respuesta.encode('utf-8'))
        else:
            client_socket.send("Acción no reconocida en la solicitud".encode('utf-8'))

    # Cerrar la conexión y el cursor al final del hilo
    app.miCursor.close()
    app.laConexion.close()




# Aceptar conexiones de clientes
while True:
    client_socket, client_address = server_socket.accept()
    print(f"Conexión aceptada desde {client_address[0]}:{client_address[1]}")
    
    # Agregar el socket del cliente a la lista de conexiones
    client_connections.append(client_socket)
    
    # Iniciar un subproceso para manejar la comunicación con el cliente
    client_thread = threading.Thread(target=handle_client, args=(client_socket,))
    client_thread.start()
